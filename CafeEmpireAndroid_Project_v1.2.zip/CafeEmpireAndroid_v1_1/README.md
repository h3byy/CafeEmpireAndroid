# Cafe Empire Android v1.2

A refreshed Kotlin + Jetpack Compose cafe-management prototype.

## v1.2 changes
- Synchronous SharedPreferences commits after state changes for more reliable local persistence.
- Save data uses a new v2 preference namespace. Existing v1.1 installs start with a fresh v2 save; reinstalling or clearing app data still removes local saves.
- Animated customer walking path, animated baristas, steam, and plant sway.
- Refreshed cafe scene with windows, menu board, counter, tables, cups, plants, and warmer visual palette.

## Build
Run `gradle assembleDebug` from this project directory with Android SDK configured.

This is still a 2D Compose illustration with animated sprites/shapes, not a true 3D game engine.
