package com.example.cafeempire

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.random.Random

private val bg = Color(0xFF101B25)
private val panel = Color(0xFF1D2D3B)
private val cream = Color(0xFFFFE9C9)
private val orange = Color(0xFFFFA64D)
private val mint = Color(0xFF79DCC0)
private val pink = Color(0xFFFF8FA3)
private val gold = Color(0xFFFFD166)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CafeEmpire() }
    }
}

@Composable
fun CafeEmpire() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("cafe_empire_save", Context.MODE_PRIVATE) }
    var cash by remember { mutableIntStateOf(prefs.getInt("cash", 500)) }
    var reputation by remember { mutableIntStateOf(prefs.getInt("reputation", 1)) }
    var served by remember { mutableIntStateOf(prefs.getInt("served", 0)) }
    var beans by remember { mutableIntStateOf(prefs.getInt("beans", 18)) }
    var milk by remember { mutableIntStateOf(prefs.getInt("milk", 14)) }
    var pastry by remember { mutableIntStateOf(prefs.getInt("pastry", 10)) }
    var price by remember { mutableIntStateOf(prefs.getInt("price", 35)) }
    var baristas by remember { mutableIntStateOf(prefs.getInt("baristas", 0)) }
    var machine by remember { mutableIntStateOf(prefs.getInt("machine", 1)) }
    var seats by remember { mutableIntStateOf(prefs.getInt("seats", 4)) }
    var customers by remember { mutableIntStateOf(prefs.getInt("customers", 0)) }
    var day by remember { mutableIntStateOf(prefs.getInt("day", 1)) }
    var lastSale by remember { mutableIntStateOf(0) }
    var notice by remember { mutableStateOf("Hoş geldin! Kafen bugün açık.") }
    var tab by remember { mutableStateOf("KAFE") }
    var ticks by remember { mutableIntStateOf(0) }

    // Save synchronously after every state change, rather than waiting for an async disk write.
    SideEffect {
        prefs.edit()
            .putInt("cash", cash).putInt("reputation", reputation).putInt("served", served)
            .putInt("beans", beans).putInt("milk", milk).putInt("pastry", pastry)
            .putInt("price", price).putInt("baristas", baristas).putInt("machine", machine)
            .putInt("seats", seats).putInt("customers", customers).putInt("day", day)
            .putInt("save_version", 2).commit()
    }

    LaunchedEffect(Unit) {
        while (true) {
            delay(2200)
            ticks++
            if (ticks % 28 == 0) {
                day++
                notice = "Yeni gün başladı • Gün $day"
            }
            if (customers < seats + 3 && Random.nextFloat() < 0.82f) customers++
            if (customers > 0 && beans > 0 && milk > 0) {
                val servedNow = minOf(customers, 1 + baristas + machine / 2)
                customers = (customers - servedNow).coerceAtLeast(0)
                cash += servedNow * price
                served += servedNow
                beans = (beans - servedNow).coerceAtLeast(0)
                milk = (milk - servedNow).coerceAtLeast(0)
                if (served / 10 > (served - servedNow) / 10) reputation = (reputation + 1).coerceAtMost(5)
                lastSale = servedNow * price
                notice = "$servedNow müşteri servis aldı • +${lastSale} ₺"
            } else if (beans == 0 || milk == 0) {
                notice = "Stok azaldı! Malzeme satın al."
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = orange, background = bg, surface = panel)) {
        Column(
            Modifier.fillMaxSize().background(bg).padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("CAFE EMPIRE", color = cream, fontSize = 24.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                    Text("KÜÇÜK BİR KAFE, BÜYÜK BİR HAYAL", color = mint, fontSize = 9.sp, letterSpacing = 1.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("$cash ₺", color = gold, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    Text("GÜN $day", color = cream.copy(alpha = .75f), fontSize = 11.sp)
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Metric("KASADAKİ", "$customers", Modifier.weight(1f), pink)
                Metric("SERVİS", "$served", Modifier.weight(1f), mint)
                Metric("İTİBAR", "★ $reputation/5", Modifier.weight(1f), gold)
            }
            Spacer(Modifier.height(10.dp))
            Box(Modifier.weight(1f).fillMaxWidth().background(Color(0xFF263746), RoundedCornerShape(18.dp)).padding(8.dp)) {
                CafeScene(customers, seats, baristas, ticks, Modifier.fillMaxSize())
                Text("KAHVE & TATLI", Modifier.align(Alignment.TopStart).padding(9.dp), color = cream, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text("SON SATIŞ  +$lastSale ₺", Modifier.align(Alignment.BottomEnd).padding(9.dp), color = gold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(7.dp))
            Text(notice, color = mint, fontSize = 11.sp, maxLines = 1)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf("KAFE", "MENÜ", "PERSONEL").forEach { t ->
                    Button(
                        onClick = { tab = t }, modifier = Modifier.weight(1f).height(42.dp),
                        shape = RoundedCornerShape(13.dp), contentPadding = PaddingValues(3.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = if (tab == t) orange else panel)
                    ) { Text(t, color = if (tab == t) bg else cream, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                }
            }
            Spacer(Modifier.height(8.dp))
            Column(Modifier.fillMaxWidth().background(panel, RoundedCornerShape(16.dp)).padding(10.dp)) {
                when (tab) {
                    "KAFE" -> {
                        Text("KAFE GELİŞTİRME", color = cream, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Spacer(Modifier.height(6.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Action("☕ Çekirdek", "$beans", "80 ₺ / +20", Modifier.weight(1f)) { if (cash >= 80) { cash -= 80; beans += 20; notice = "Çekirdek stoğu yenilendi." } }
                            Action("🥛 Süt", "$milk", "55 ₺ / +20", Modifier.weight(1f)) { if (cash >= 55) { cash -= 55; milk += 20; notice = "Süt stoğu yenilendi." } }
                            Action("🥐 Tatlı", "$pastry", "45 ₺ / +12", Modifier.weight(1f)) { if (cash >= 45) { cash -= 45; pastry += 12; notice = "Tatlı stoğu yenilendi." } }
                        }
                        Spacer(Modifier.height(6.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Action("🪑 Masa", "$seats", "180 ₺ / +2", Modifier.weight(1f)) { if (cash >= 180) { cash -= 180; seats += 2; notice = "Oturma alanı büyüdü." } }
                            Action("⚙ Makine", "Lv.$machine", "300 ₺ / +1", Modifier.weight(1f)) { if (cash >= 300) { cash -= 300; machine++; notice = "Kahve makinesi geliştirildi." } }
                        }
                    }
                    "MENÜ" -> {
                        Text("MENÜ FİYATI", color = cream, fontWeight = FontWeight.Bold)
                        Text("Ortalama ürün fiyatı: $price ₺", color = gold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Action("Fiyatı düşür", "−5 ₺", "Daha ulaşılabilir", Modifier.weight(1f)) { price = (price - 5).coerceAtLeast(10) }
                            Action("Fiyatı artır", "+5 ₺", "Daha yüksek gelir", Modifier.weight(1f)) { price = (price + 5).coerceAtMost(100) }
                        }
                    }
                    else -> {
                        Text("PERSONEL YÖNETİMİ", color = cream, fontWeight = FontWeight.Bold)
                        Text("Barista sayısı: $baristas", color = mint, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("Her barista servis kapasitesini artırır.", color = cream, fontSize = 10.sp)
                        Action("👨‍🍳 Barista işe al", "250 ₺", "Servis kapasitesi +1", Modifier.fillMaxWidth()) { if (cash >= 250) { cash -= 250; baristas++; notice = "Yeni barista ekibe katıldı!" } }
                    }
                }
            }
            Spacer(Modifier.height(5.dp))
            Text("OTOMATİK KAYIT AÇIK  •  İŞLETMEN SENİN", color = Color(0xFF91A5B7), fontSize = 8.sp)
        }
    }
}

@Composable
private fun CafeScene(customers: Int, seats: Int, baristas: Int, ticks: Int, modifier: Modifier) {
    val transition = rememberInfiniteTransition(label = "cafe-people")
    val walk by transition.animateFloat(0f, 1f, infiniteRepeatable(tween(1900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "walk")
    val steam by transition.animateFloat(0f, 1f, infiniteRepeatable(tween(950), RepeatMode.Restart), label = "steam")
    val sway by transition.animateFloat(-3f, 3f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "sway")
    Canvas(modifier) {
        val w = size.width; val h = size.height
        fun poly(points: List<Offset>, color: Color) {
            val p = Path().apply { moveTo(points[0].x, points[0].y); points.drop(1).forEach { lineTo(it.x, it.y) }; close() }
            drawPath(p, color)
        }
        // Warm wall, large windows and a patterned floor.
        drawRect(Color(0xFF9A6B50))
        drawRoundRect(Color(0xFF4A3440), Offset(w*.06f, h*.035f), Size(w*.88f, h*.17f), CornerRadius(18f))
        repeat(3) { i ->
            val x = w * (.13f + i*.29f)
            drawRoundRect(Color(0xFF9ED3D0), Offset(x, h*.055f), Size(w*.20f, h*.115f), CornerRadius(8f))
            drawRect(Color(0xFFFAE0B8), Offset(x+w*.095f, h*.055f), Size(w*.012f, h*.115f))
        }
        drawRect(Color(0xFFB98765), Offset(0f,h*.22f), Size(w,h*.78f))
        val tileW = w*.105f; val tileH = h*.055f
        var yy = h*.22f
        var row = 0
        while (yy < h) {
            var xx = if (row%2==0) 0f else -tileW/2
            while (xx < w) {
                poly(listOf(Offset(xx+tileW/2,yy),Offset(xx+tileW,yy+tileH/2),Offset(xx+tileW/2,yy+tileH),Offset(xx,yy+tileH/2)), if ((row+(xx/tileW).toInt())%2==0) Color(0xFFD5AD88) else Color(0xFFC99B77))
                xx += tileW
            }
            yy += tileH; row++
        }
        // Counter and espresso machine.
        drawRoundRect(Color(0xFF54372F), Offset(w*.10f,h*.265f), Size(w*.80f,h*.16f), CornerRadius(22f))
        drawRoundRect(Color(0xFF80523D), Offset(w*.10f,h*.245f), Size(w*.80f,h*.105f), CornerRadius(18f))
        drawRoundRect(Color(0xFF273F50), Offset(w*.39f,h*.205f), Size(w*.22f,h*.105f), CornerRadius(10f))
        drawRoundRect(Color(0xFFFFB15A), Offset(w*.47f,h*.235f), Size(w*.06f,h*.025f), CornerRadius(7f))
        // Menu board.
        drawRoundRect(Color(0xFF263A3D), Offset(w*.70f,h*.045f), Size(w*.22f,h*.12f), CornerRadius(8f))
        repeat(3) { i -> drawLine(Color(0xFFFFD9A8), Offset(w*.735f,h*(.075f+i*.028f)), Offset(w*.88f,h*(.075f+i*.028f)), 3f) }
        // Tables, chairs and cups.
        val tablePos = listOf(.24f to .54f, .72f to .54f, .24f to .79f, .72f to .79f)
        tablePos.take(seats.coerceIn(1,4)).forEach { (px,py) ->
            val x=w*px; val y=h*py
            drawCircle(Color(0xFF684332), w*.105f, Offset(x,y+h*.02f))
            drawCircle(Color(0xFFB9784E), w*.085f, Offset(x,y))
            drawCircle(Color(0xFFFFD8AC), w*.075f, Offset(x,y-h*.012f))
            drawRoundRect(Color(0xFF6C4638), Offset(x-w*.12f,y-h*.018f), Size(w*.045f,h*.045f), CornerRadius(8f))
            drawRoundRect(Color(0xFF6C4638), Offset(x+w*.075f,y-h*.018f), Size(w*.045f,h*.045f), CornerRadius(8f))
            drawCircle(Color(0xFFF8F0DE), w*.018f, Offset(x+w*.035f,y-h*.04f))
        }
        // Moving customers: a visible entrance-to-table path, not static circles.
        drawRoundRect(Color(0xFF3B2C31), Offset(w*.83f,h*.86f), Size(w*.12f,h*.12f), CornerRadius(8f))
        drawRoundRect(Color(0xFFB8D6D0), Offset(w*.845f,h*.875f), Size(w*.09f,h*.095f), CornerRadius(5f))
        val walkerX = w*(.89f - .50f*walk)
        val walkerY = h*(.86f - .26f*walk)
        if (customers > 0) {
            drawLine(Color(0xFFFFE2BE).copy(alpha=.55f), Offset(w*.88f,h*.83f), Offset(w*.39f,h*.60f), 3f, pathEffect = null)
            drawRoundRect(Color(0xFF34536A), Offset(walkerX-w*.025f,walkerY-h*.055f+sway), Size(w*.05f,h*.065f), CornerRadius(10f))
            drawCircle(Color(0xFFFFD2AE), w*.025f, Offset(walkerX,walkerY-h*.075f+sway))
            drawLine(Color(0xFF243746), Offset(walkerX-w*.012f,walkerY+h*.01f), Offset(walkerX-w*.022f,walkerY+h*.045f), 4f)
            drawLine(Color(0xFF243746), Offset(walkerX+w*.012f,walkerY+h*.01f), Offset(walkerX+w*.022f,walkerY+h*.045f), 4f)
        }
        // Baristas moving behind the counter.
        repeat(baristas.coerceAtMost(2)+1) { i ->
            val bx=w*(.34f+i*.25f)
            drawCircle(Color(0xFFFFD2AE), w*.025f, Offset(bx,h*.255f+sway*.4f))
            drawRoundRect(Color(0xFF3D7880), Offset(bx-w*.03f,h*.28f+sway*.4f), Size(w*.06f,h*.075f), CornerRadius(9f))
            drawLine(Color(0xFFFFD2AE), Offset(bx-w*.025f,h*.31f), Offset(bx-w*.055f,h*.335f+walk*5f), 4f)
            drawLine(Color(0xFFFFD2AE), Offset(bx+w*.025f,h*.31f), Offset(bx+w*.055f,h*.335f+walk*5f), 4f)
        }
        // Animated steam over cups.
        repeat(3) { i ->
            val sx=w*(.43f+i*.07f); val sy=h*(.205f - steam*.025f)
            drawLine(Color(0xFFFFF0D8).copy(alpha=.8f-steam*.35f), Offset(sx,sy+h*.035f), Offset(sx+w*.008f,sy), 3f, cap=androidx.compose.ui.graphics.StrokeCap.Round)
        }
        // Potted plants.
        listOf(.07f,.93f).forEach { px ->
            drawRoundRect(Color(0xFF80523D), Offset(w*px-w*.035f,h*.88f), Size(w*.07f,h*.065f), CornerRadius(8f))
            drawCircle(Color(0xFF72CFAE), w*.065f, Offset(w*px,h*.86f+sway))
            drawCircle(Color(0xFF91E0BD), w*.035f, Offset(w*px-w*.035f,h*.84f+sway))
        }
    }
}

@Composable
private fun Metric(label: String, value: String, modifier: Modifier, color: Color) {
    Column(modifier.background(panel, RoundedCornerShape(13.dp)).padding(vertical=9.dp), horizontalAlignment=Alignment.CenterHorizontally) {
        Text(label, color=Color(0xFF9AABBA), fontSize=8.sp, letterSpacing=.5.sp)
        Text(value, color=color, fontSize=17.sp, fontWeight=FontWeight.Black)
    }
}

@Composable
private fun Action(title: String, value: String, detail: String, modifier: Modifier, onClick: () -> Unit) {
    Button(onClick, modifier.heightIn(min=66.dp), shape=RoundedCornerShape(12.dp), colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF30475A)), contentPadding=PaddingValues(5.dp)) {
        Column(horizontalAlignment=Alignment.CenterHorizontally) {
            Text(title, color=cream, fontSize=10.sp, fontWeight=FontWeight.Bold)
            Text(value, color=gold, fontSize=14.sp, fontWeight=FontWeight.Black)
            Text(detail, color=Color(0xFFB5C4D0), fontSize=8.sp)
        }
    }
}
