package com.example.cafeempire

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.animation.core.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.random.Random

private val bg=Color(0xFF17202B); private val panel=Color(0xFF253342)
private val cream=Color(0xFFFFE8C7); private val orange=Color(0xFFFFA64D)
private val mint=Color(0xFF7FE0C3); private val pink=Color(0xFFFF8FA3); private val gold=Color(0xFFFFD166)

class MainActivity:ComponentActivity(){ override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState); setContent { CafeEmpire() }} }

@Composable fun CafeEmpire(){
 val context = LocalContext.current
 val prefs = remember { context.getSharedPreferences("cafe_empire_save", android.content.Context.MODE_PRIVATE) }
 var cash by remember { mutableIntStateOf(prefs.getInt("cash", 500)) }; var reputation by remember { mutableIntStateOf(prefs.getInt("reputation", 1)) }
 var served by remember { mutableIntStateOf(prefs.getInt("served", 0)) }; var beans by remember { mutableIntStateOf(prefs.getInt("beans", 18)) }
 var milk by remember { mutableIntStateOf(prefs.getInt("milk", 14)) }; var pastry by remember { mutableIntStateOf(prefs.getInt("pastry", 10)) }
 var price by remember { mutableIntStateOf(prefs.getInt("price", 35)) }; var baristas by remember { mutableIntStateOf(prefs.getInt("baristas", 0)) }
 var machine by remember { mutableIntStateOf(prefs.getInt("machine", 1)) }; var seats by remember { mutableIntStateOf(prefs.getInt("seats", 4)) }
 var customers by remember { mutableIntStateOf(prefs.getInt("customers", 0)) }; var day by remember { mutableIntStateOf(prefs.getInt("day", 1)) }
 var notice by remember { mutableStateOf("Kafen hazır! İlerlemen otomatik kaydediliyor.") }; var lastSale by remember { mutableIntStateOf(0) }
 var tab by remember { mutableStateOf("KAFE") }
 SideEffect {
  prefs.edit().putInt("cash",cash).putInt("reputation",reputation).putInt("served",served)
   .putInt("beans",beans).putInt("milk",milk).putInt("pastry",pastry).putInt("price",price)
   .putInt("baristas",baristas).putInt("machine",machine).putInt("seats",seats)
   .putInt("customers",customers).putInt("day",day).apply()
 }
 var ticks by remember { mutableIntStateOf(0) }
 LaunchedEffect(Unit){ while(true){ delay(2600); ticks++; if(customers<seats+2 && Random.nextFloat()<.78f) customers++
   if(ticks % 23 == 0){ day++; notice="Yeni gün başladı! Gün $day" }
   if(customers>0 && beans>0 && milk>0){ val n=minOf(customers,1+baristas+machine/2); customers-=n
    cash+=n*price; served+=n; beans=(beans-n).coerceAtLeast(0); milk=(milk-n).coerceAtLeast(0); lastSale=n*price
    if(served>0 && served%10<n) reputation=(reputation+1).coerceAtMost(5)
    notice="$n müşteri servis aldı. +${n*price} ₺"
   } else if(beans==0 || milk==0) notice="Stok azaldı! Malzeme satın al."
 }}
 MaterialTheme(colorScheme=darkColorScheme(primary=orange,background=bg,surface=panel)){
  Column(Modifier.fillMaxSize().background(bg).padding(13.dp), horizontalAlignment=Alignment.CenterHorizontally){
   Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
    Column(Modifier.weight(1f)){ Text("CAFE EMPIRE",color=cream,fontSize=23.sp,fontWeight=FontWeight.Black,letterSpacing=2.sp); Text("KÜÇÜK BİR KAFE, BÜYÜK BİR HAYAL",color=mint,fontSize=9.sp) }
    Column(horizontalAlignment=Alignment.End){ Text("$cash ₺",color=gold,fontSize=21.sp,fontWeight=FontWeight.Bold); Text("GÜN $day",color=cream.copy(alpha=.7f),fontSize=10.sp) }
   }
   Spacer(Modifier.height(10.dp))
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){
    Metric("MÜŞTERİ",customers.toString(),Modifier.weight(1f),pink); Metric("SERVİS",served.toString(),Modifier.weight(1f),mint); Metric("İTİBAR","⭐ $reputation/5",Modifier.weight(1f),gold)
   }
   Spacer(Modifier.height(10.dp))
   Box(Modifier.weight(1f).fillMaxWidth().background(Color(0xFF344354),RoundedCornerShape(17.dp)).padding(8.dp)){
    CafeScene(customers,seats,baristas,machine,ticks,Modifier.fillMaxSize())
    Text("KAFE KAT PLANI",Modifier.align(Alignment.TopStart).padding(7.dp),color=cream,fontSize=9.sp,fontWeight=FontWeight.Bold)
    Text("Son satış: +$lastSale ₺",Modifier.align(Alignment.BottomEnd).padding(7.dp),color=gold,fontSize=11.sp,fontWeight=FontWeight.Bold)
   }
   Spacer(Modifier.height(7.dp)); Text(notice,color=mint,fontSize=11.sp,maxLines=1)
   Spacer(Modifier.height(7.dp))
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){ listOf("KAFE","MENÜ","PERSONEL").forEach { t ->
    Button(onClick={tab=t},modifier=Modifier.weight(1f).height(38.dp),contentPadding=PaddingValues(3.dp),colors=ButtonDefaults.buttonColors(containerColor=if(tab==t)orange else panel)){Text(t,color=if(tab==t)bg else cream,fontSize=10.sp,fontWeight=FontWeight.Bold)}
   }}
   Spacer(Modifier.height(6.dp))
   Column(Modifier.fillMaxWidth().background(panel,RoundedCornerShape(13.dp)).padding(9.dp)){
    when(tab){
     "KAFE"->{
      Text("KAFE GELİŞTİRME",color=cream,fontWeight=FontWeight.Bold,fontSize=12.sp)
      Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(5.dp)){
       Action("☕ Çekirdek","$beans","80 ₺ / +20",Modifier.weight(1f)){if(cash>=80){cash-=80;beans+=20;notice="Kahve çekirdeği alındı."}}
       Action("🥛 Süt","$milk","55 ₺ / +20",Modifier.weight(1f)){if(cash>=55){cash-=55;milk+=20;notice="Süt stoğu yenilendi."}}
       Action("🥐 Tatlı","$pastry","45 ₺ / +12",Modifier.weight(1f)){if(cash>=45){cash-=45;pastry+=12;notice="Tatlı stoğu yenilendi."}}
      }
      Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(5.dp)){
       Action("🪑 Masa","$seats","180 ₺ / +2",Modifier.weight(1f)){if(cash>=180){cash-=180;seats+=2;notice="Yeni masa alanı açıldı."}}
       Action("⚙ Makine","Lv.$machine","300 ₺ / +1",Modifier.weight(1f)){if(cash>=300){cash-=300;machine++;notice="Makine geliştirildi!"}}
      }
     }
     "MENÜ"->{
      Text("MENÜ FİYATI",color=cream,fontWeight=FontWeight.Bold)
      Text("Ortalama ürün fiyatı: $price ₺",color=gold,fontSize=17.sp,fontWeight=FontWeight.Bold)
      Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
       Action("Fiyatı düşür","−5 ₺","Daha çok müşteri",Modifier.weight(1f)){price=(price-5).coerceAtLeast(10)}
       Action("Fiyatı artır","+5 ₺","Daha çok gelir",Modifier.weight(1f)){price=(price+5).coerceAtMost(100)}
      }
     }
     else->{
      Text("PERSONEL YÖNETİMİ",color=cream,fontWeight=FontWeight.Bold)
      Text("Barista sayısı: $baristas",color=mint,fontSize=17.sp,fontWeight=FontWeight.Bold)
      Text("Her barista servis kapasitesini artırır.",color=cream,fontSize=10.sp)
      Action("👨‍🍳 Barista işe al","250 ₺","Servis kapasitesi +1",Modifier.fillMaxWidth()){if(cash>=250){cash-=250;baristas++;notice="Yeni barista işe alındı!"}}
     }
    }
   }
   Spacer(Modifier.height(4.dp)); Text("İŞLETMEN SENİN • OTOMATİK SERVİS AKTİF",color=Color(0xFF8193A6),fontSize=8.sp)
  }
 }
}

@Composable private fun CafeScene(customers:Int,seats:Int,baristas:Int,machine:Int,ticks:Int,modifier:Modifier){
 val transition = rememberInfiniteTransition(label = "cafe_motion")
 val bob by transition.animateFloat(initialValue = -2f, targetValue = 2f, animationSpec = infiniteRepeatable(tween(850, easing = FastOutSlowInEasing), repeatMode = RepeatMode.Reverse), label = "bob")
 Canvas(modifier){
  val w=size.width;val h=size.height
  fun diamond(cx:Float,cy:Float,rx:Float,ry:Float,c:Color){val p=Path().apply{moveTo(cx,cy-ry);lineTo(cx+rx,cy);lineTo(cx,cy+ry);lineTo(cx-rx,cy);close()};drawPath(p,c)}
  drawRect(Color(0xFFB98C68))
  var y=-42f
  while(y<h+42){var x=-42f;while(x<w+42){diamond(x+42,y+21,42f,21f,if((((x/42).toInt()+(y/42).toInt())%2)==0)Color(0xFFC99D78) else Color(0xFFD5AC87));x+=42};y+=42}
  drawRect(Color(0xFF76513F),Offset.Zero,Size(w,h*.15f))
  drawRoundRect(Color(0xFF6A3F32),Offset(w*.12f,h*.16f),Size(w*.76f,h*.13f),androidx.compose.ui.geometry.CornerRadius(16f))
  drawRoundRect(Color(0xFF263C4B),Offset(w*.40f,h*.09f),Size(w*.20f,h*.12f),androidx.compose.ui.geometry.CornerRadius(9f))
  drawCircle(orange,w*.018f,Offset(w*.50f,h*.15f))
  val pos=listOf(.22f to .42f,.72f to .42f,.25f to .70f,.72f to .72f,.49f to .82f)
  pos.take(minOf(5,seats.coerceAtLeast(1))).forEachIndexed{i,p->
   val cx=w*p.first;val cy=h*p.second
   drawCircle(Color(0xFF805039),w*.095f,Offset(cx,cy+h*.018f));diamond(cx,cy,w*.085f,h*.045f,Color(0xFFFFD7A8))
   drawCircle(Color(0xFF6C4639),w*.026f,Offset(cx-w*.11f,cy));drawCircle(Color(0xFF6C4639),w*.026f,Offset(cx+w*.11f,cy))
   if(i<customers){drawCircle(Color(0xFF3E526B),w*.032f,Offset(cx + ((ticks+i)%3-1)*w*.006f,cy-h*.085f+bob));drawCircle(Color(0xFFFFD0A8),w*.023f,Offset(cx + ((ticks+i)%3-1)*w*.006f,cy-h*.13f+bob))}
  }
  listOf(.08f,.91f).forEach{px->drawCircle(Color(0xFF80513B),w*.045f,Offset(w*px,h*.87f));drawCircle(mint,w*.055f,Offset(w*px,h*.82f))}
  repeat(baristas.coerceAtMost(3)){i->val bx=w*(.38f+i*.12f);drawCircle(Color(0xFFFFD0A8),w*.025f,Offset(bx,h*.245f+bob*.5f));drawRoundRect(Color(0xFF315C69),Offset(bx-w*.025f,h*.265f+bob*.5f),Size(w*.05f,h*.07f),androidx.compose.ui.geometry.CornerRadius(8f))}
  listOf(.25f,.5f,.75f).forEach{lx->drawCircle(gold,w*.012f,Offset(w*lx,h*.055f))}
 }
}

@Composable private fun Metric(label:String,value:String,modifier:Modifier,color:Color){
 Column(modifier.background(panel,RoundedCornerShape(11.dp)).padding(vertical=8.dp),horizontalAlignment=Alignment.CenterHorizontally){Text(label,color=Color(0xFF9AABBA),fontSize=8.sp);Text(value,color=color,fontSize=16.sp,fontWeight=FontWeight.Bold)}
}
@Composable private fun Action(title:String,value:String,detail:String,modifier:Modifier,onClick:()->Unit){
 Button(onClick,modifier.heightIn(min=64.dp),shape=RoundedCornerShape(10.dp),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF34485B)),contentPadding=PaddingValues(5.dp)){
  Column(horizontalAlignment=Alignment.CenterHorizontally){Text(title,color=cream,fontSize=10.sp,fontWeight=FontWeight.Bold);Text(value,color=gold,fontSize=13.sp,fontWeight=FontWeight.Black);Text(detail,color=Color(0xFFB5C4D0),fontSize=8.sp)}
 }
}
