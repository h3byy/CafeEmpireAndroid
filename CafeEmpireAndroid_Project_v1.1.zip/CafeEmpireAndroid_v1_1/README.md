# Cafe Empire Android — v1.1

Cafe Empire is a portrait Android cafe-management prototype built with Kotlin and Jetpack Compose.

## v1.1 updates
- Automatic local save using Android SharedPreferences.
- Restores cash, reputation, served customers, inventory, prices, staff, machine level, seats, waiting customers and day.
- Light idle animation for customers and baristas.
- In-game day advances automatically during play.

## Build
Open the project in Android Studio or upload the project to GitHub and run the included Android Actions workflow. The workflow produces a debug APK artifact.

This is a prototype; test the generated APK on your device before wider distribution.
